let farmer;
let trees = [];
let score = 0;
let gameOver = false;

function setup() {
  createCanvas(800, 500);
  farmer = new Farmer(width / 2, height - 100);  // Personagem fazendeiro
  noStroke();
}

function draw() {
  if (gameOver) {
    background(255, 0, 0);  // Cor de fundo para "game over"
    textSize(48);
    fill(255);
    textAlign(CENTER, CENTER);
    text("GAME OVER", width / 2, height / 2);
    textSize(24);
    text(`Score: ${score}`, width / 2, height / 2 + 50);
    return;
  }

  // Desenhar o céu com nuvens (área menor)
  background(135, 206, 250);  // Céu azul claro
  drawClouds();  // Função para desenhar as nuvens
  
  // Desenhar o chão com grama (expandido para cobrir mais área)
  drawGround();

  // Desenhar as árvores
  for (let tree of trees) {
    tree.fall();  // A árvore cai com o tempo
    tree.display();  // Exibe a árvore

    // Verifica se o fazendeiro colidiu com a árvore
    if (tree.checkCollision(farmer)) {
      gameOver = true;
    }
  }

  // Exibir o fazendeiro
  farmer.update();  // Atualiza a posição do fazendeiro
  farmer.display();  // Exibe o fazendeiro

  // Exibir a pontuação
  fill(0);
  textSize(24);
  text(`Score: ${score}`, 20, 40);
}

// Função para desenhar o céu com nuvens (área reduzida)
function drawClouds() {
  fill(255);  // Cor das nuvens (branco)
  // Nuvens em várias posições
  ellipse(150, 100, 100, 50);
  ellipse(300, 120, 120, 60);
  ellipse(500, 80, 90, 45);
  ellipse(700, 150, 110, 55);
}

// Função para desenhar o chão com grama (expandido)
function drawGround() {
  fill(34, 139, 34);  // Cor do chão (verde, como grama)
  rect(0, height - 50, width, 50);  // Chão
  
  // Adicionando mais grama para um efeito mais realista
  drawGrass();
}

// Função para desenhar grama (mais densa)
function drawGrass() {
  fill(50, 205, 50);  // Cor da grama (verde mais vibrante)
  for (let i = 0; i < width; i += 5) {  // Mais densa (passos menores)
    let grassHeight = random(10, 25);  // Altura aleatória da grama (aumentei um pouco)
    line(i, height - 50, i, height - 50 - grassHeight);  // Desenha a grama
  }
}

// Classe do Fazendeiro
class Farmer {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 30;
    this.speed = 5;
  }

  update() {
    if (keyIsDown(65)) { // Tecla 'A' para mover para a esquerda
      this.x -= this.speed;
    }
    if (keyIsDown(68)) { // Tecla 'D' para mover para a direita
      this.x += this.speed;
    }
    if (keyIsDown(87)) { // Tecla 'W' para mover para cima
      this.y -= this.speed;
    }
    if (keyIsDown(83)) { // Tecla 'S' para mover para baixo
      this.y += this.speed;
    }
  }

  display() {
    fill(139, 69, 19);  // Cor do corpo (marrom, como um fazendeiro)
    ellipse(this.x, this.y, this.size);  // Corpo do fazendeiro
    fill(255, 215, 0);  // Cor do chapéu (amarelo)
    ellipse(this.x, this.y - 20, this.size / 1.5, this.size / 3);  // Chapéu
  }
}

// Classe da Árvore
class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = 10; // Inicia pequena
    this.growthRate = 0.5; // Taxa de crescimento
    this.maxSize = 50; // Tamanho máximo
    this.fallSpeed = 3; // Velocidade da queda
  }

  // Faz a árvore cair para baixo
  fall() {
    if (this.size < this.maxSize) {
      this.size += this.growthRate; // A árvore cresce a cada chamada
    }
    this.y += this.fallSpeed; // A árvore vai para baixo
  }

  // Verifica se o fazendeiro colidiu com a árvore
  checkCollision(farmer) {
    let d = dist(this.x, this.y, farmer.x, farmer.y);
    return d < this.size + farmer.size / 2; // Colisão quando a árvore e o fazendeiro se tocam
  }

  display() {
    fill(34, 139, 34); // Cor das folhas (verde)
    ellipse(this.x, this.y - this.size / 2, this.size, this.size);  // Desenha as folhas
    fill(139, 69, 19);  // Cor do tronco (marrom)
    rect(this.x - 5, this.y, 10, this.size / 2);  // Desenha o tronco
  }
}

// Função para adicionar uma árvore ao clicar na tela
function mousePressed() {
  // Cria uma nova árvore na posição do mouse
  let tree = new Tree(mouseX, 0); // Árvores começam no topo da tela
  trees.push(tree);  // Adiciona a árvore à lista
  score++;  // Aumenta a pontuação
}
